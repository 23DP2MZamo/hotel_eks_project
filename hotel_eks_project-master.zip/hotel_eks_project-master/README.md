# hotel_eks_project
### Maksims Zamovskis, Timurs Massans DP2-2 system
PROGRAMMU NEVAR PALAIST, JA JAVA VALODA NAV INSTALĒTA!
1. Ja Jūs razarhīve no githuba vai no jebkur sistēmu, atveriet otro folder-u ar nosaukumu hotel_eks_project-master
2. Lai palaist programmu vajag palaist failu Main.java (ja neielādējas vai nav informāciju csv failā, tad ieladējiet pirmkārt failu CsvRoomSeeder.java)
3. Būs 5 varianti 1-rezervēt istabu
                  2-paradīt nerezervētas istabas
                  3-aizvert programmu
                  4-paradīt jūsu rezervētas istabas
                  5-atcelt rezervējumu
4. Rezervācijas būs tik ilgas, cik vien nepieciešams, līdz jūs atceļat rezervāciju.