# Hotel Management System

A modern, user-friendly hotel management system built in Java that helps manage room reservations, availability, and guest information.

## Features

- **Room Management**
  - View all rooms with detailed information
  - Search rooms by price range, type, or floor
  - Real-time room availability tracking
  - Multiple room types (Single, Duo, Luxury, Presidential)

- **Reservation System**
  - Make new reservations
  - View existing reservations
  - Cancel reservations
  - Date validation and leap year handling
  - Maximum stay duration of 30 days

- **User Interface**
  - Clean, table-based display
  - Color-coded status indicators
  - Intuitive menu navigation
  - Clear error messages and confirmations

## Prerequisites

- Java Development Kit (JDK) 17 or higher
- Maven (for building the project)

## Installation

1. Clone the repository:
   ```bash
   git clone [your-repository-url]
   cd hotel-management-system
   ```

2. Build the project using Maven:
   ```bash
   mvn clean install
   ```

3. Run the application:
   ```bash
   java -jar target/hotel-management-system.jar
   ```

## Usage Guide

### Main Menu Options

1. **View All Rooms**
   - Displays a table of all rooms with their current status
   - Shows room number, floor, type, beds, availability, price, and guest information

2. **Search Rooms**
   - Search by Price Range: Find rooms within your budget
   - Search by Room Type: Filter by SINGLE, DUO, LUX, or PRESIDENT
   - Search by Floor: View rooms on specific floors

3. **Make Reservation**
   - Select a room number
   - Enter guest name
   - Choose check-in and check-out dates
   - System validates dates and room availability

4. **View My Reservations**
   - Enter guest name to view all your reservations
   - Shows reservation ID, room number, dates, and guest information

5. **Cancel Reservation**
   - View your reservations
   - Enter reservation ID to cancel
   - System automatically updates room availability

### Date Format

- Use the format: YYYY-MM-DD
- Example: 2024-03-20
- Valid year range: 2024-2030
- Cannot make reservations for past dates
- Maximum stay duration: 30 days

### Room Types and Pricing

- **Single Rooms** (Floors 1-3)
  - 1 bed
  - Price: $20.00 per night

- **Duo Rooms** (Floors 4-5)
  - 2 beds
  - Price: $30.00 per night

- **Luxury Rooms** (Floors 6-10)
  - 3 beds
  - Price: $40.00 per night

- **Presidential Suite** (Floor 11)
  - 5 beds
  - Price: $1000.00 per night

## Data Storage

- Room information is stored in `src/main/resources/rooms.csv`
- Reservation data is stored in `src/main/resources/reservations.csv`
- Data is automatically saved after each operation

## Important Notes

1. **Date Validation**
   - System automatically handles leap years
   - Cannot make reservations for past dates
   - Check-out date must be after check-in date
   - Maximum stay duration is 30 days

2. **Room Availability**
   - Rooms are marked as "Available" or "Booked"
   - System prevents double-booking
   - Room status updates automatically after reservations/cancellations

3. **Error Handling**
   - Clear error messages for invalid inputs
   - Automatic validation of dates and room numbers
   - User-friendly prompts for corrections

## Technical Details

- Built with Java
- Uses CSV files for data persistence
- Implements console-based UI with ASCII tables
- Includes comprehensive date validation
- Features color-coded status indicators

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Authors

- Your Name - Initial work

## Acknowledgments

- Thanks to all contributors
- Inspired by modern hotel management systems