# hotel_eks_project
### Maksims Zamovskis, Timurs Massans DP2-2 system
PROGRAMMU NEVAR PALAIST, JA JAVA VALODA NAV INSTALĒTA!
1. Lai palaist programmu vajag palaist failu Main.java (ja neielādējas vai nav informāciju csv failā, tad ieladējiet pirmkārt failu CsvRoomSeeder.java)
2. Būs 5 varianti 1-rezervēt istabu
                  2-paradīt nerezervētas istabas
                  3-aizvert programmu
                  4-paradīt jūsu rezervētas istabas
                  5-atcelt rezervējumu
3. Rezervācijas būs tik ilgas, cik vien nepieciešams, līdz jūs atceļat rezervāciju.